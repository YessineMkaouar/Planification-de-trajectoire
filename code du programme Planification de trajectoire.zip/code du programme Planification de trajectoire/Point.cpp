#include "Point.h"
#include <bits/stdc++.h>
Point::Point() : x(0),y(0)
{
}
Point::Point(double x, double y) : x(x),y(y)
{
}
void Point::setx(double x){this->x = x;}
void Point::sety(double y){this->y = y;}
double Point::getx(){return x;}
double Point::gety(){return y;}
double Point::distance(const Point &P)
{
 double dx, dy;
 dx = x - P.x;
 dy = y - P.y;
 return sqrt(dx*dx + dy*dy);
}


bool operator==(Point P1,Point P2)
{
    if(abs(P1.x-P2.x)<0.01 && abs(P1.y-P2.y)<0.01)
        return true ;
    else
        return false ;
}

bool operator!=(Point P1,Point P2)
{
    if(abs(P1.x-P2.x)<0.1 && abs(P1.y-P2.y)<0.1)
        return false ;
    else
        return true ;
}

ostream & operator<<(ostream & out, const Point &P)
{
 out << "(" << P.x <<","<<P.y<<")";
 return out;
}



