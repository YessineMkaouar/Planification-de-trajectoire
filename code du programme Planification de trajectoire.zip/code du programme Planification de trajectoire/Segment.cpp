#include "Segment.h"
#include <bits/stdc++.h>

Segment::Segment()
{
    P1.setx(0);
    P1.sety(0);
    P2.setx(0);
    P2.sety(0);

}
Segment::Segment(Point A, Point B)
{
    P1.setx(A.getx());
    P1.sety(A.gety());
    P2.setx(B.getx());
    P2.sety(B.gety());
}
void Segment::setP1(Point A)
{
    P1.setx(A.getx());
    P1.sety(A.gety());
}
void Segment::setP2(Point B)
{P2.setx(B.getx());
P2.sety(B.gety());
}
Point Segment::getP1(){return P1;}
Point Segment::getP2(){return P2;}


double Segment::getLongueur(){return P1.distance(P2);}

bool Segment::intersect(Segment s2)
{
	float x1=P2.getx()-P1.getx();
	float y1=P2.gety()-P1.gety();
    float x2=s2.getP2().getx()-s2.getP1().getx();
	float y2=s2.getP2().gety()-s2.getP1().gety();
    double determinant = x1*y2-y1*x2;

    return (determinant != 0);
}

bool operator==(Segment S1,Segment S2)
{
    if(S1.getP1()==S2.getP1() && S2.getP2()==S1.getP2())
        return true ;
    else
        return false ;
}

bool operator!=(Segment S1,Segment S2)
{
        if(S1.getP1()==S2.getP1() && S2.getP2()==S1.getP2())
        return false ;
    else
        return true;
}
